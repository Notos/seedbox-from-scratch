# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "0.7.6"
__baseline__ = "bc6b3091ebf54e7739235198f9bd054d1e190e0c"
