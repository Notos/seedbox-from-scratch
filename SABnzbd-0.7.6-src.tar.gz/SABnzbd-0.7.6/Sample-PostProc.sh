#!/bin/sh
# Example of a post processing script for SABnzbd

echo
echo Started as $0
echo
echo "The first parameter (result-dir)  =" "$1"
echo "The second parameter (nzb-name)   =" "$2"
echo "The third parameter (nice name)   =" "$3"
echo "The fourth parameter (newzbin-id) =" "$4"
echo "The fifth parameter (category)    =" "$5"
echo "The sixth parameter (group)       =" "$6"
echo "The seventh parameter (status)    =" "$7"
echo


