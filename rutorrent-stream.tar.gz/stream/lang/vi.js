﻿

 theUILang.streamData		= "Lấy dữ liệu";
 theUILang.cantAccessData	= "Máy chủ Web không thể truy cập dữ liệu của torrent này.";

thePlugins.get("stream").langLoaded();